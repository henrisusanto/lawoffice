<?php
include '../common.php';

$bookingLangObj->saveTexts();
?>
<script>
	window.parent.hideLoader();
</script>
