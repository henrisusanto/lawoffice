<?php
	_deprecated_file( __FILE__, '3.10', 'Tribe__Events__Template_Factory' );


	class Tribe_Template_Factory extends Tribe__Events__Template_Factory {

	}