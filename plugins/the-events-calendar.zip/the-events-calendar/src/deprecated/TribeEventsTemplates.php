<?php
	_deprecated_file( __FILE__, '3.10', 'Tribe__Events__Templates' );


	class TribeEventsTemplates extends Tribe__Events__Templates {

	}